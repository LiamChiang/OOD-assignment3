//#ifndef GAMESTATE_H
//#define GAMESTATE_H

//#include "gamememento.h"
//#include <vector>

//class GameState
//{
//public:
////    virtual ~GameState(){}
//    virtual void setTargetedState(std::vector<GameMemento*> state) = 0;
//};

//class CueBallStopState: public GameState{
//    void setTargetedState(std::vector<GameMemento*> state){

//    }
//};


//#endif // GAMESTATE_H
