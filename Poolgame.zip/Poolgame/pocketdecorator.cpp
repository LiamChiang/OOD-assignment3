//#include "pocketdecorator.h"

//void PocketMovingDecorator::render(QPainter &painter, const QVector2D &offset){
//    m_subPocket->render(painter, offset);
//    for(int i = 0; i < 100; ++i){
//        m_subPocket->changePosition(QVector2D(i,i));
//    }
//    QVector2D absolutePos = offset + m_subPocket->getPosition();
//    painter.setBrush(m_subPocket->getColourBrush());
//    painter.drawEllipse(absolutePos.toPointF(), m_subPocket->getRadius(), m_subPocket->getRadius());
//}

