/**
  *     Written by Tim Burr
  *     2018/05/18
  */

#include "dialog.h"
#include "game.h"
#include "utils.h"
#include "gamebuilder.h"
#include "stagetwobuilder.h"
#include "stagethreebuilder.h"
#include <QApplication>
#include <QFile>
#include <iostream>
#include <QString>
#include <QJsonObject>
#include <ctime>
#include <QJsonDocument>
#include <QDebug>

QJsonObject loadConfig() {
    // load json from config file
    QFile conf_file(config_path);
    conf_file.open(QIODevice::ReadOnly | QIODevice::Text);
    QString content = conf_file.readAll();
    conf_file.close();
    QJsonObject config = QJsonDocument::fromJson(content.toUtf8()).object();
    return config;
}

int main(int argc, char *argv[])
{
    QJsonObject conf = loadConfig();

    // seed our RNG
    srand(time(nullptr));

    // create our game based on our config
    GameDirector director(&conf);
    Game* game;
    // use builder2 if we're stage two (defaults to false), otherwise no
    if (conf.value("stage2").toBool(false) == true && conf.value("stage3").toBool(false) == false) {
       director.setBuilder(new StageTwoBuilder());
       game = director.createGame();
    }
    else if(conf.value("stage3").toBool(false) == true){
        qDebug() << "call stage3";
        director.setBuilder(new StageThreeBuilder());
        game = director.createGame();
        game->triggerStage3();
    }
    else {
        // set and transfer ownership of this builder to the director
        director.setBuilder(new StageOneBuilder());
        game = director.createGame();
    }



    // display our dialog that contains our game and run
    QApplication a(argc, argv);
    Dialog w(game, nullptr);
    w.show();

    return a.exec();
}
