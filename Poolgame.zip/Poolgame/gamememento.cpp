#include "gamememento.h"

//GameMemento::~GameMemento()
//{
//    for (Ball* b : *m_ballstate){
//        delete b;
//    }
//}
