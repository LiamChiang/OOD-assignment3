//#include "gameoriginator.h"

//GameOriginator::GameMemento()
//{

//}
